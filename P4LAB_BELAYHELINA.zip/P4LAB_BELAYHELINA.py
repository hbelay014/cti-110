import turtle

# Create a turtle object
t = turtle.Turtle()

# Draw a square using a for loop
for _ in range(4):  # Use range(4) to loop four times
    t.forward(100)  # Move forward by 100 units
    t.left(90)      # Turn left by 90 degrees to make square corners

# Reposition the turtle to start drawing the triangle
t.penup()           # Lift the pen to move without drawing
t.goto(-150, 0)     # Move to a new starting point (adjust as necessary)
t.pendown()         # Put the pen down to start drawing

# Draw a triangle using a for loop
for _ in range(3):  # Use range(3) to loop three times for a triangle
    t.forward(100)  # Move forward by 100 units
    t.left(120)     # Turn left by 120 degrees to form the triangle corners

# Hide the turtle and display the window
turtle.done()

